var x = "       ..---..                          .'  _    `.                    __..'  (o)    :                   `..__          ;                        `.       /                           ;      `..---...___              .'                   `~-. .-')    .                         ' _.'   :                           :      \                           '       +                         J         `._                   _.'             `~--....___...---~'        ";


function printDuck(flatRepStr){
    if(!flatRepStr) return "";
    var positon=0;
    while(positon<flatRepStr.length){
    console.log(flatRepStr.substring(positon, positon+35));
    positon+=35;
    }
}

printDuck(x);

