var x = "       ..---..                          .'  _    `.                    __..'  (o)    :                   `..__          ;                        `.       /                           ;      `..---...___              .'                   `~-. .-')    .                         ' _.'   :                           :      \                           '       +                         J         `._                   _.'             `~--....___...---~'        ";


function stringWithoutO(str){
    if(!str) return "";
    let indxEye = str.indexOf("o");
    if(indxEye === -1) return str;

    return str.substring(0,indxEye)+'_'+str.substring(indxEye+1);
}
function printClosedEyeDuck(flatRepStr){
    if(!flatRepStr) return "";
    var positon=0;
    var eyeFound=false;
    while(positon<flatRepStr.length){
        let currentLine = flatRepStr.substring(positon, positon+35);
        if(!eyeFound && currentLine.includes("o")){
            eyeFound=true;
            currentLine=stringWithoutO(currentLine);
        }
        
        console.log(currentLine);
        positon+=35;
    }
}

printClosedEyeDuck(x);

